README

1. Move the mfli folder to the src directory, so the structure is src/mfli/mcts
2. In Executor.java, run the controller by inserting the following line:
	exec.runGameTimed(new MCTSPacman(), << GHOST CONTROLLER >>, visual);